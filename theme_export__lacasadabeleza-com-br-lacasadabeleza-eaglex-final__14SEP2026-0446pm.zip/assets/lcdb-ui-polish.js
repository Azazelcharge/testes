(() => {
  if (window.__lcdbUiPolish) return;
  window.__lcdbUiPolish = true;
  const html = document.documentElement;
  document.addEventListener('click', event => {
    const trigger = event.target instanceof Element ? event.target.closest('[data-lcdb-open]') : null;
    if (!trigger || innerWidth >= 990) return;
    event.preventDefault();
    if (trigger.dataset.lcdbOpen === 'categories') {
      // Invoke the native summary: its default action and theme handler work together.
      const details = document.getElementById('Details-menu-drawer-container');
      if (details && !details.open) details.querySelector('summary')?.click();
    } else {
      const drawer = document.getElementById('cart-drawer');
      if (typeof drawer?.open === 'function') drawer.open();
    }
  });
  const sheet = document.getElementById('lcdb-account-sheet');
  let previousFocus = null;
  let closing = false;
  let closeTimer;
  const finishClose = () => {
    clearTimeout(closeTimer);
    if (sheet?.open) sheet.close();
    sheet?.classList.remove('is-closing');
    html.classList.remove('lcdb-account-open');
    previousFocus?.setAttribute('aria-expanded', 'false');
    if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    previousFocus = null;
    closing = false;
  };
  const close = () => {
    if (!sheet?.open || closing) return;
    closing = true;
    sheet.classList.add('is-closing');
    closeTimer = setTimeout(finishClose, matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 210);
  };
  document.addEventListener('click', (event) => {
    if (!(event.target instanceof Element)) return;
    const trigger = event.target.closest('.beauty-account-click-target, .beauty-compact-action[href*="/account"]');
    if (trigger && innerWidth < 990 && sheet && typeof sheet.showModal === 'function') {
      event.preventDefault(); event.stopImmediatePropagation();
      if (sheet.open) return;
      previousFocus = trigger;
      trigger.setAttribute('aria-expanded', 'true');
      sheet.showModal();
      html.classList.add('lcdb-account-open');
      sheet.querySelector('[data-account-close]')?.focus();
    }
    if (event.target.closest('#lcdb-account-sheet [data-account-close]')) close();
  }, true);
  sheet?.addEventListener('cancel', event => { event.preventDefault(); close(); });
  sheet?.addEventListener('click', event => {
    if (event.target !== sheet) return;
    const box = sheet.getBoundingClientRect();
    if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) close();
  });
  sheet?.addEventListener('close', () => html.classList.remove('lcdb-account-open'));
  matchMedia('(min-width: 990px)').addEventListener('change', event => { if (event.matches && sheet?.open) finishClose(); });

  // Measure real bar height, including wrapped prices and safe-area padding.
  let frame = 0;
  const observed = new Set();
  const updateClearance = () => {
    frame = 0;
    let clearance = 0;
    for (const bar of document.querySelectorAll('sticky-add-to-cart .sticky-add-to-cart__bar')) {
      const host = bar.closest('sticky-add-to-cart');
      if (bar.dataset.stuck !== 'true' || host?.dataset.variantAvailable !== 'true') continue;
      const style = getComputedStyle(bar);
      if (style.display === 'none' || style.visibility === 'hidden') continue;
      clearance = Math.max(clearance, bar.offsetHeight + Math.max(0, parseFloat(style.bottom) || 0));
    }
    html.style.setProperty('--lcdb-sticky-clearance', Math.ceil(clearance) + 'px');
  };
  const schedule = () => { if (!frame) frame = requestAnimationFrame(updateClearance); };
  const resize = typeof ResizeObserver === 'function' ? new ResizeObserver(schedule) : null;
  const observer = new MutationObserver(schedule);
  const connect = () => {
    observer.disconnect(); resize?.disconnect(); observed.clear();
    document.querySelectorAll('sticky-add-to-cart').forEach(host => {
      observer.observe(host, { attributes: true, attributeFilter: ['data-variant-available', 'data-stuck'], subtree: true, childList: true });
      host.querySelectorAll('.sticky-add-to-cart__bar').forEach(bar => { resize?.observe(bar); observed.add(bar); });
    });
    schedule();
  };
  connect();
  document.addEventListener('shopify:section:load', connect);
  window.addEventListener('resize', schedule, { passive: true });
  window.addEventListener('pageshow', event => { if (event.persisted) finishClose(); connect(); });
})();
