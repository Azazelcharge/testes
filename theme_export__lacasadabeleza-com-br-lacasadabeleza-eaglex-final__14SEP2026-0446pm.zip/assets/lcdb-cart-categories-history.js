// Panel history is independent of Shopify cart contents.
(() => {
  if (window.__lcdbCartCategoriesHistory) return;
  window.__lcdbCartCategoriesHistory = true;
  const key = 'lcdbPanel';
  let owned = false, consuming = false, closing = false, frame = 0;
  const entries = () => [...document.querySelectorAll(
    '#cart-drawer[open], #Details-menu-drawer-container[open], [data-beauty-compact-menu-panel]:not([hidden])'
  )].filter(node => node.getClientRects().length);
  const close = node => {
    if (node.contains(document.activeElement)) document.activeElement?.blur();
    if (node.matches('theme-drawer')) node.close();
    else if (node.matches('#Details-menu-drawer-container')) node.closest('header-drawer')?.close();
    else node.querySelector('[data-beauty-compact-menu-close]')?.click();
  };
  const sync = () => {
    frame = 0;
    const panels = entries();
    if (closing) {
      if (panels.length) return;
      closing = false;
    }
    if (consuming) return;
    if (panels.length && !owned) {
      history.pushState({ ...(history.state || {}), [key]: true }, '', location.href);
      owned = true;
    } else if (!panels.length && owned) {
      owned = false;
      if (history.state?.[key]) { consuming = true; history.back(); }
    }
  };
  const schedule = () => { if (!frame) frame = requestAnimationFrame(sync); };
  const observer = new MutationObserver(schedule);
  const connect = () => {
    observer.disconnect();
    document.querySelectorAll('#cart-drawer, #Details-menu-drawer-container, [data-beauty-compact-menu-panel]')
      .forEach(node => observer.observe(node, { attributes: true, attributeFilter: ['open', 'hidden'] }));
    schedule();
  };
  window.addEventListener('popstate', () => {
    if (consuming) { consuming = false; schedule(); return; }
    if (!owned) { schedule(); return; }
    owned = false;
    closing = true;
    entries().forEach(close);
    schedule();
  });
  window.addEventListener('pageshow', event => {
    if (event.persisted || history.state?.[key]) {
      owned = false; consuming = false; closing = true;
      if (history.state?.[key]) {
        const state = { ...history.state }; delete state[key];
        history.replaceState(state, '', location.href);
      }
      entries().forEach(close);
    }
    connect();
  });
  document.addEventListener('shopify:section:load', connect);
  document.addEventListener('click', () => queueMicrotask(connect), { capture: true });
  connect();
})();
