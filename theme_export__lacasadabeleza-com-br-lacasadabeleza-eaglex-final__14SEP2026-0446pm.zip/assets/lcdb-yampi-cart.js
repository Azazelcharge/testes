import { StandardEvents, CartLinesUpdateEvent } from '@shopify/events';

// Same endpoint and payload as the installed Yampi integration.
const endpoint = 'https://api.dooki.com.br/v2/public/shopify/cart';
const config = document.getElementById('lcdb-yampi-config');
const root = (config?.dataset.cartRoot || '/').replace(/\/?$/, '/');
const selector = '[data-yampi-checkout]';
const pending = new Set();
let busy = false;
let failures = 0;
let generation = 0;
let locked = [];
let controller;
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Track theme-owned updates instead of replacing quantity/remove handlers.
function trackMutation(event) {
  if (!event.promise) return;
  const task = Promise.resolve(event.promise).then((result) => {
    if (result?.detail?.didError) failures++;
    else document.dispatchEvent(new CustomEvent('lcdb:cart-updated'));
  }, () => { failures++; });
  pending.add(task);
  task.then(() => pending.delete(task));
}
for (const name of [StandardEvents.cartLinesUpdate, StandardEvents.cartDiscountUpdate, StandardEvents.cartNoteUpdate]) {
  if (name) document.addEventListener(name, trackMutation);
}

function withUtms(url) {
  const target = new URL(url);
  const cookie = document.cookie.split('; ').find((entry) => entry.startsWith('utmsTrack='));
  const utms = new URLSearchParams(cookie ? cookie.slice('utmsTrack='.length) : '');
  const current = new URLSearchParams(window.location.search);
  for (const key of ['utm_source', 'utm_campaign', 'utm_term', 'utm_medium', 'utm_content']) {
    if (current.has(key)) utms.set(key, current.get(key));
    if (utms.has(key)) target.searchParams.set(key, utms.get(key));
  }
  const ga = document.cookie.split('; ').find((entry) => entry.startsWith('_ga='));
  if (ga) target.searchParams.set('_ga', ga.slice(4));
  return target.href;
}
window.ymp_getUrlWithUtms = withUtms;
try {
  const tracked = new URL(withUtms(window.location.href)).searchParams;
  const saved = new URLSearchParams();
  for (const key of ['utm_source', 'utm_campaign', 'utm_term', 'utm_medium', 'utm_content']) {
    if (tracked.has(key)) saved.set(key, tracked.get(key));
  }
  if (saved.size) document.cookie = `utmsTrack=${saved.toString()}; path=/; max-age=2592000; SameSite=Lax; Secure`;
} catch (_) { /* Checkout remains available if cookie access is restricted. */ }

function setBusy(value) {
  busy = value;
  for (const button of document.querySelectorAll(selector)) {
    const label = button.querySelector('.button-text') || button;
    if (value) {
      button.dataset.yampiLabel = label.textContent;
      button.setAttribute('aria-busy', 'true');
      label.textContent = 'Preparando pagamento…';
    } else {
      button.removeAttribute('aria-busy');
      if (button.dataset.yampiLabel) label.textContent = button.dataset.yampiLabel;
      delete button.dataset.yampiLabel;
    }
  }
  if (value) {
    locked = Array.from(document.querySelectorAll('cart-items-component, .beauty-cart-preview')).map((element) => [element, element.inert]);
    for (const [element] of locked) element.inert = true;
  } else {
    for (const [element, inert] of locked) element.inert = inert;
    locked = [];
  }
}

function message(text, origin) {
  const current = origin?.isConnected ? origin : document.querySelector('#cart-drawer[open] [data-yampi-checkout]') || document.querySelector(selector);
  const container = current?.closest('.cart__ctas, .beauty-cart-preview') || document.querySelector('.cart-page') || document.body;
  let element = container.querySelector('.lcdb-yampi-cart-message');
  if (!element) {
    element = document.createElement('p');
    element.className = 'lcdb-yampi-cart-message';
    element.setAttribute('role', 'alert');
    element.tabIndex = -1;
    container.append(element);
  }
  element.textContent = text;
  element.focus({ preventScroll: true });
}

async function json(url, options = {}) {
  const response = await fetch(url, { ...options, signal: controller.signal });
  if (!response.ok) throw new Error('O serviço de pagamento não respondeu. Tente novamente.');
  return response.json();
}

async function checkout(origin) {
  if (busy) return;
  if (window.Shopify?.designMode) {
    message('Abra a prévia da loja fora do editor para testar a finalização.', origin);
    return;
  }
  document.querySelectorAll('.lcdb-yampi-cart-message').forEach((element) => element.remove());
  const attempt = ++generation;
  const initialFailures = failures;
  setBusy(true);
  controller = new AbortController();
  let timeout;
  const deadline = new Promise((_, reject) => {
    timeout = setTimeout(() => {
      controller.abort();
      reject(new Error('A conexão demorou mais que o esperado. Tente finalizar novamente.'));
    }, 25000);
  });
  let navigating = false;
  try {
    const work = async () => {
      // Quantity debounce is 300 ms; notes use 200 ms in this theme.
      await pause(400);
      while (pending.size) await Promise.all(Array.from(pending));
      if (attempt !== generation || controller.signal.aborted) throw new Error('Finalização cancelada.');
      if (failures !== initialFailures) throw new Error('Uma alteração do carrinho não foi concluída. Confira os itens e tente novamente.');
      const cart = await json(root + 'cart.js', { credentials: 'same-origin', cache: 'no-store' });
      if (!Array.isArray(cart.items) || !cart.items.length) throw new Error('Seu carrinho está vazio. Adicione um produto para continuar.');
      const result = await json(endpoint, {
        method: 'POST', credentials: 'omit',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify({ shop: location.host, shopify_internal_domain: config?.dataset.shopDomain, cart_payload: cart })
      });
      if (!result.active || typeof result.checkout_direct_url !== 'string' || !result.checkout_direct_url.trim()) {
        throw new Error('Não foi possível abrir o pagamento agora. Seus itens continuam no carrinho. Tente novamente.');
      }
      const url = new URL(result.checkout_direct_url);
      if (url.protocol !== 'https:' || url.username || url.password) throw new Error('O endereço de pagamento recebido é inválido.');
      let target = url.href;
      try { target = withUtms(target); } catch (_) {}
      return target;
    };
    const target = await Promise.race([work(), deadline]);
    if (attempt !== generation) return;
    // Preserve the Shopify cart for back navigation and error recovery.
    window.location.assign(target);
    navigating = true;
  } catch (error) {
    if (attempt !== generation) return;
    setBusy(false);
    message(error?.name === 'AbortError' ? 'A conexão foi interrompida. Tente novamente.' : error.message || 'Não foi possível abrir o pagamento. Tente novamente.', origin);
  } finally {
    clearTimeout(timeout);
    if (!navigating && attempt === generation) setBusy(false);
  }
}

document.addEventListener('click', (event) => {
  const button = event.target instanceof Element ? event.target.closest(selector) : null;
  if (!button) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  if (button.disabled) return;
  checkout(button);
}, true);

// Prevent implicit checkout submits from bypassing Yampi (e.g. keyboard).
document.addEventListener('submit', (event) => {
  if (!(event.target instanceof HTMLFormElement)) return;
  if (event.target.id !== 'cart-form') return;
  const submitter = event.submitter;
  if (submitter?.name === 'update') return;
  event.preventDefault();
  event.stopImmediatePropagation();
  checkout(document.querySelector(selector));
}, true);

window.addEventListener('pageshow', (event) => {
  generation++;
  controller?.abort();
  setBusy(false);
});

// Return refresh is owned by lcdb-cart-state.js.
