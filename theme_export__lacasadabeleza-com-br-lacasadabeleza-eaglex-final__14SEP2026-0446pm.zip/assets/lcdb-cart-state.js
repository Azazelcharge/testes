import { StandardEvents, CartLinesUpdateEvent } from '@shopify/events';

// One counter source for native, compact and floating cart buttons.
let revision = 0;
let request;
let total = null;
let pendingMutations = 0;
let refreshTimer;
let needsRefresh = false;
function scheduleRefresh() {
  needsRefresh = true;
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => { if (!pendingMutations) refresh(); }, 450);
}
const root = window.Shopify?.routes?.root || '/';
function paint(count) {
  if (!Number.isFinite(count) || count < 0) return;
  total = count;
  document.querySelectorAll('cart-icon').forEach(icon => icon.renderCartBubble?.(count, false));
  document.querySelectorAll('[data-lcdb-cart-count]').forEach(badge => {
    const text = String(count);
    if (badge.textContent !== text) badge.textContent = text;
    badge.hidden = count === 0;
  });
  document.querySelectorAll('.lcdb-float--cart').forEach(button => {
    button.setAttribute('aria-label', 'Abrir carrinho: ' + count + ' itens');
  });
}
function trackMutation(event) {
  if (event.lcdbRefresh || !event.promise) return;
  const current = ++revision;
  request?.abort();
  needsRefresh = true;
  pendingMutations++;
  event.promise?.then(({cart, detail}) => {
    if (current !== revision || detail?.didError) return;
    const count = cart?.totalQuantity ?? detail?.itemCount;
    if (typeof count === 'number') paint(count);
  }).catch(() => {}).finally(() => {
    pendingMutations--;
    if (needsRefresh) scheduleRefresh();
  });
}
document.addEventListener(StandardEvents.cartLinesUpdate, trackMutation);
document.addEventListener('lcdb:cart-mutation', event => trackMutation({promise: event.detail.promise}));
async function refresh() {
  if (pendingMutations) { needsRefresh = true; return; }
  needsRefresh = false;
  request?.abort();
  request = new AbortController();
  const version = ++revision;
  try {
    const response = await fetch(root + 'cart.js', {cache:'no-store',credentials:'same-origin',signal:request.signal});
    if (!response.ok) return;
    const cart = await response.json();
    if (version !== revision) return;
    paint(cart.item_count);
    const event = new CartLinesUpdateEvent({
      action:'update',context:'cart',lines:[],
      promise:Promise.resolve({
        cart:CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
        detail:{itemCount:cart.item_count,items:cart.items,source:'lcdb-cart-refresh'}
      })
    });
    event.lcdbRefresh = true;
    document.dispatchEvent(event);
  } catch (_) {}
}
window.addEventListener('pageshow', scheduleRefresh);
window.addEventListener('focus', scheduleRefresh);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') scheduleRefresh();
});
document.addEventListener('theme-drawer:open', event => {
  if (event.target?.id === 'cart-drawer') scheduleRefresh();
});
setInterval(() => {
  if (document.visibilityState === 'visible' && document.querySelector('#cart-drawer[open], .cart-page')) scheduleRefresh();
}, 15000);
scheduleRefresh();
document.addEventListener('shopify:section:load', () => {if(total!==null)paint(total);});
// Show the Liquid count immediately while the server refresh is pending.
const initial = document.querySelector('[data-lcdb-cart-count]');
if(initial)paint(Number(initial.textContent.trim()));

document.addEventListener('click', event => {
  const link = event.target instanceof Element ? event.target.closest('[data-lcdb-cart-open]') : null;
  if(!link)return;
  const drawer=document.getElementById('cart-drawer');
  if(typeof drawer?.open!=='function')return;
  event.preventDefault();event.stopImmediatePropagation();
  document.querySelectorAll('.beauty-action-preview-popover').forEach(panel=>{
    try{if(panel.matches(':popover-open'))panel.hidePopover();}catch(_){}
    panel.hidden=true;
    panel._bhWrap?.classList.remove('is-open');
    panel._bhTrigger?.setAttribute('aria-expanded','false');
  });
  drawer.open();
},true);
